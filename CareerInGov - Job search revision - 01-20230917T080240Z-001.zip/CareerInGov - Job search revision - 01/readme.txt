Job card revisions implemented in the searchRevised.css 
tTe modified styles can found in revisions.css(for reference)
